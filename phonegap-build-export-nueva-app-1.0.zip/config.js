define( function ( require ) {

	"use strict";

	return {
		app_slug : 'nueva-app',
		wp_ws_url : 'http://procons.e-webportal.com.br/test/wordpress/wp-appkit-api/nueva-app',
		wp_url : 'http://procons.e-webportal.com.br/test/wordpress',
		theme : 'q-android',
		version : '1.0',
		app_type : 'phonegap-build',
		app_title : 'nueva appcre',
		app_platform : 'android',
		app_path: '',
		gmt_offset : 0,
		debug_mode : 'off',
		auth_key : 'EnJ]x!VRkIKysp4K&a{tB:* ABAxI23,65l|9pF=nin{${!w?J=dZ@r&py}U%.sf',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
